package com.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.crud.DbConnection;
import com.google.gson.Gson;
import com.pojo.Pojo;

/**
 * Servlet implementation class Search
 */
@WebServlet("/Search")
public class Search extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Search() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		HashMap<Object,Object> Response=new HashMap<Object,Object>();
		ArrayList<Pojo> ALLPojo=new ArrayList<Pojo>();
		response.setHeader("Access-Control-Allow-Origin","*");
		try {
			Connection con=DbConnection.getConnection();
			String sql_query="SELECT * FROM winter_internship WHERE doc_id=?"
					+ "AND cust_number=? AND invoice_id=? AND buisness_year=?;";
			PreparedStatement st=con.prepareStatement(sql_query);
			st.setString(1, request.getParameter("doc_id"));
			st.setInt(2,Integer.parseInt(request.getParameter("cust_number")));
			st.setInt(3, Integer.parseInt(request.getParameter("invoice_id")));
			st.setInt(4, Integer.parseInt(request.getParameter("buisness_year")));
			ResultSet rs=st.executeQuery();			
			while(rs.next()) {
				Pojo s=new Pojo();				
				s.setSl_no(rs.getInt("sl_no"));
				s.setBusiness_code(rs.getString("business_code"));
				s.setCust_number(rs.getInt("cust_number"));
				s.setClear_date(rs.getDate("clear_date"));
				s.setBuisness_year(rs.getInt("buisness_year"));
				s.setDoc_id(rs.getString("doc_id"));
				s.setPosting_date(rs.getDate("posting_date"));
				s.setDocument_create_date(rs.getDate("document_create_date"));
				s.setDue_in_date(rs.getDate("due_in_date"));
				s.setInvoice_currency(rs.getString("invoice_currency"));
				s.setDocument_type(rs.getString("document_type"));
				s.setPosting_id(rs.getInt("posting_id"));
				s.setTotal_open_amount(rs.getFloat("total_open_amount"));
				s.setBaseline_create_date(rs.getDate("baseline_create_date"));
				s.setCust_payment_terms(rs.getString("cust_payment_terms"));
				s.setInvoice_id(rs.getInt("invoice_id"));
				s.setAging_bucket(rs.getString("aging_bucket"));				
				/*s.setIsOpen(isOpen);				
				s.setIs_deleted(is_deleted);*/
				
				ALLPojo.add(s);
				
			}
			Response.put("Pojo",ALLPojo);
			for(Pojo poj:ALLPojo) {
				System.out.println(poj.toString());
			}
		}catch(Exception e) {
			System.out.println(e);
			
		}
		//ArrayList<Pojo> data = fetchdata.getData();
		//System.out.println(data);
	  	
	  	Gson gson = new Gson();
	  	String respData = gson.toJson(Response);
		
		try {
			response.getWriter().print(respData);
		}catch(Exception e) {
			e.printStackTrace();
		}
			
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);	
		
		
	}

}
