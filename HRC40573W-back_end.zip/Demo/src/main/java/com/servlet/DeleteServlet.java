package com.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.crud.DbConnection;
import com.google.gson.Gson;
import com.pojo.Pojo;


/**
 * Servlet implementation class DeleteServlet
 */
@WebServlet("/Delete")
public class DeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		response.setHeader("Access-Control-Allow-Origin","*");
		response.setContentType("application/json");
		HashMap<Object,Object> Response=new HashMap<Object,Object>();
		try {
			//Gson gson=new Gson();
			//Pojo  p=gson.fromJson(sl_no, Pojo.class);
			//System.out.println(p.getSl_no());
			//p.sl_no=p.getSl_no();
			/*StringBuilder sl_no=new StringBuilder();
			System.out.println(request.getParameterValues("sl_no"));
			for(String sl:request.getParameterValues("sl_no")) {
				sl_no.append(sl).append(",");
			}
			sl_no.deleteCharAt(sl_no.length()-1);*/
			Connection con=DbConnection.getConnection();
			String sql_query="DELETE FROM winter_internship WHERE sl_no=?;";
			PreparedStatement st=con.prepareStatement(sql_query);
			st.setInt(1,Integer.parseInt(request.getParameter("sl_no")));
			//st.setString(1,sl_no);
			//response.sendRedirect("list");
			if(st.executeUpdate()>0) {
				System.out.println("Record Deleted Successfully");
				Response.put("delete",true);
			}
			else Response.put("delete",false);
			
			Gson gson = new Gson();
			String respData = gson.toJson(Response);
			
			
			
			response.getWriter().append(respData);
			
		}
		catch(Exception e) {
			System.out.println(e);
		}
	}

}
