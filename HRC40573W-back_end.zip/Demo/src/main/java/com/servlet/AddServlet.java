package com.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.sql.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.crud.DbConnection;
import com.google.gson.Gson;

/**
 * Servlet implementation class Fetch
 */
@WebServlet("/Add")
public class AddServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		 
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		response.setHeader("Access-Control-Allow-Origin","*");
		response.setContentType("application/json");
		HashMap<Object,Object> Response=new HashMap<Object,Object>();
		
		try {
			DateFormat formatter=new SimpleDateFormat("yyyy-MM-dd");
			System.out.println(new Date(formatter.parse(request.getParameter("clear_date")).getTime()));
			Connection con=DbConnection.getConnection();
			String sql_query="INSERT INTO "
					+ "winter_internship"
					+ "(business_code,cust_number,clear_date,buisness_year,"
					+ "doc_id,posting_date,document_create_date,due_in_date,"
					+ "invoice_currency,document_type,posting_id,total_open_amount,"
					+ "baseline_create_date,cust_payment_terms,invoice_id) VALUES "
					+ "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
			PreparedStatement st=con.prepareStatement(sql_query);
			st.setString(1, request.getParameter("business_code"));
			st.setInt(2, Integer.parseInt(request.getParameter("cust_number")));
			st.setDate(3, new Date(formatter.parse(request.getParameter("clear_date")).getTime()));
			st.setInt(4,Integer.parseInt(request.getParameter("buisness_year")));
			st.setString(5, request.getParameter("doc_id"));
			st.setDate(6, new Date(formatter.parse(request.getParameter("posting_date")).getTime()));
			st.setDate(7, new Date(formatter.parse(request.getParameter("document_create_date")).getTime()));
			st.setDate(8,new Date(formatter.parse(request.getParameter("document_create_date")).getTime()));
			st.setString(9, request.getParameter("invoice_currency"));
			st.setString(10, request.getParameter("document_type"));
			st.setInt(11,Integer.parseInt(request.getParameter("posting_id")));
			st.setFloat(12, Float.parseFloat(request.getParameter("total_open_amount")));
			st.setDate(13, new Date(formatter.parse(request.getParameter("document_create_date")).getTime()));
			st.setString(14, request.getParameter("cust_payment_terms"));
			st.setInt(15, Integer.parseInt(request.getParameter("invoice_id")));
			if(st.executeUpdate()>0) {
				System.out.println("Added Successfully");
				Response.put("insert",true);
			}
			else Response.put("insert",false);
			
			Gson gson = new Gson();
			String respData = gson.toJson(Response);
			
			
			
			response.getWriter().append(respData);
			
		}catch(Exception e) {
			e.printStackTrace();
		}		
		
	}

}

