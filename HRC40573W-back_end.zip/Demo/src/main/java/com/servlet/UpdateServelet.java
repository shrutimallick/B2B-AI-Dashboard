package com.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.crud.DbConnection;
import com.google.gson.Gson;

/**
 * Servlet implementation class EditServelet
 */
@WebServlet("/Edit")
public class UpdateServelet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateServelet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		response.setHeader("Access-Control-Allow-Origin","*");
		response.setContentType("application/json");
		HashMap<Object,Object> Response=new HashMap<Object,Object>();
		
		try {			
			Connection con=DbConnection.getConnection();
			String sql_query="UPDATE winter_internship SET invoice_currency= ?, cust_payment_terms = ? WHERE sl_no = ?";
			PreparedStatement st=con.prepareStatement(sql_query);
			st.setString(1,request.getParameter("invoice_currency"));
			st.setString(2, request.getParameter("cust_payment_terms"));
			st.setInt(3,Integer.parseInt(request.getParameter("sl_no")));
			
			if(st.executeUpdate()>0) {
				System.out.println("Updated Successfully");
				Response.put("update",true);
			}
			else Response.put("update",false);
			
			Gson gson = new Gson();
			String respData = gson.toJson(Response);
			
			
			
			response.getWriter().append(respData);
			
		}catch(Exception e) {
			e.printStackTrace();
			System.out.println(e);
		}
	}

}
